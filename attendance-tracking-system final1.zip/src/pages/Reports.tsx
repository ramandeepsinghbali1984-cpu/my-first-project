import Layout from '../components/layout/Layout';
import { BarChart3, PieChart as PieChartIcon, Download, ArrowUpRight, ArrowDownRight, Printer } from 'lucide-react';
import { 
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts';

const data = [
  { name: 'Jan', attendance: 85, target: 75 },
  { name: 'Feb', attendance: 88, target: 75 },
  { name: 'Mar', attendance: 82, target: 75 },
  { name: 'Apr', attendance: 91, target: 75 },
  { name: 'May', attendance: 89, target: 75 },
  { name: 'Jun', attendance: 94, target: 75 },
];

const pieData = [
  { name: 'Present', value: 85, color: '#3b82f6' },
  { name: 'Late', value: 8, color: '#f59e0b' },
  { name: 'Absent', value: 7, color: '#f43f5e' },
];

const Reports = () => {
  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-white">Analytics & Reports</h2>
            <p className="text-slate-400">Deep dive into institutional attendance metrics</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 px-4 py-2.5 glass rounded-xl text-sm font-semibold hover:bg-white/10 transition-colors">
              <Printer className="w-4 h-4" />
              Print
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-brand-blue text-white rounded-xl text-sm font-semibold hover:bg-brand-blue/90 transition-all shadow-lg shadow-brand-blue/20">
              <Download className="w-4 h-4" />
              Export PDF
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white dark:bg-slate-900/40 p-6 rounded-[2rem] border border-slate-200 dark:border-white/5">
            <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Retention Rate</p>
            <div className="flex items-end gap-3">
              <h3 className="text-3xl font-bold text-slate-900 dark:text-white">94.2%</h3>
              <div className="flex items-center text-emerald-500 text-xs font-bold mb-1">
                <ArrowUpRight className="w-3.5 h-3.5" />
                2.1%
              </div>
            </div>
            <div className="mt-4 h-1.5 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-emerald-500 w-[94.2%]" />
            </div>
          </div>
          
          <div className="bg-white dark:bg-slate-900/40 p-6 rounded-[2rem] border border-slate-200 dark:border-white/5">
            <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Avg. Punctuality</p>
            <div className="flex items-end gap-3">
              <h3 className="text-3xl font-bold text-slate-900 dark:text-white">88.5%</h3>
              <div className="flex items-center text-red-500 text-xs font-bold mb-1">
                <ArrowDownRight className="w-3.5 h-3.5" />
                0.4%
              </div>
            </div>
            <div className="mt-4 h-1.5 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-blue-600 w-[88.5%]" />
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900/40 p-6 rounded-[2rem] border border-slate-200 dark:border-white/5">
            <p className="text-slate-500 dark:text-slate-400 text-xs font-bold uppercase tracking-widest mb-1">Chronic Absentees</p>
            <div className="flex items-end gap-3">
              <h3 className="text-3xl font-bold text-slate-900 dark:text-white">14</h3>
              <div className="flex items-center text-amber-500 text-xs font-bold mb-1 uppercase tracking-tighter">
                Critical Level
              </div>
            </div>
            <div className="mt-4 h-1.5 w-full bg-slate-100 dark:bg-white/5 rounded-full overflow-hidden">
              <div className="h-full bg-amber-500 w-[15%]" />
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-900/40 p-8 rounded-[2.5rem] border border-slate-200 dark:border-white/5">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="text-blue-600 w-5 h-5" />
                Monthly Participation
              </h3>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-blue-600" />
                  <span className="text-[10px] text-slate-500 font-bold uppercase">Actual</span>
                </div>
                <div className="flex items-center gap-1.5 ml-4">
                  <div className="w-2.5 h-2.5 rounded-full bg-slate-200 dark:bg-white/20" />
                  <span className="text-[10px] text-slate-500 font-bold uppercase">Target</span>
                </div>
              </div>
            </div>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-slate-200 dark:text-slate-800" />
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <Tooltip 
                    cursor={{ fill: 'rgba(0,0,0,0.02)' }}
                    contentStyle={{ backgroundColor: '#020617', border: '1px solid #1e293b', borderRadius: '12px', color: '#fff' }}
                  />
                  <Bar dataKey="attendance" fill="#2563eb" radius={[4, 4, 0, 0]} barSize={24} />
                  <Bar dataKey="target" fill="rgba(100,116,139,0.1)" radius={[4, 4, 0, 0]} barSize={24} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="glass p-8 rounded-[2.5rem] border border-white/5">
            <div className="flex items-center justify-between mb-8">
              <h3 className="text-xl font-bold text-white flex items-center gap-2">
                <PieChartIcon className="text-brand-electric w-5 h-5" />
                Status Distribution
              </h3>
              <button className="text-xs text-slate-500 hover:text-white font-medium">Last 30 Days</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center h-[300px]">
              <div className="h-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-4">
                {pieData.map((item) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-sm font-medium text-slate-400">{item.name}</span>
                    </div>
                    <span className="text-sm font-bold text-white">{item.value}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="glass p-8 rounded-[2.5rem] border border-white/5">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold text-white">Daily Tracking Comparison</h3>
            <div className="flex gap-2">
              <button className="px-3 py-1 bg-white/5 rounded-lg text-xs font-bold text-white">Daily</button>
              <button className="px-3 py-1 hover:bg-white/5 rounded-lg text-xs font-bold text-slate-500">Weekly</button>
            </div>
          </div>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '12px', color: '#fff' }}
                />
                <Line type="monotone" dataKey="attendance" stroke="#22d3ee" strokeWidth={3} dot={{ r: 4, fill: '#22d3ee' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Reports;
