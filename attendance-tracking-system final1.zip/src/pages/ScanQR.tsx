import { useState } from 'react';
import { useStore, AttendanceRecord } from '../store/useStore';
import { QrCode, ShieldCheck, MapPin, Camera, CheckCircle2, AlertCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ScanQR = () => {
  const { currentUser, sessions, addAttendance, attendance } = useStore();
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState<'SUCCESS' | 'ERROR' | 'ALREADY_MARKED' | null>(null);

  const simulateScan = () => {
    setScanning(true);
    setResult(null);

    // Simulate network and scanning delay
    setTimeout(() => {
      const activeSession = sessions.find(s => s.isActive);
      
      if (!activeSession) {
        setResult('ERROR');
        setScanning(false);
        return;
      }

      const alreadyMarked = attendance.find(
        a => a.sessionId === activeSession.id && a.studentId === currentUser?.id
      );

      if (alreadyMarked) {
        setResult('ALREADY_MARKED');
        setScanning(false);
        return;
      }

      const newRecord: AttendanceRecord = {
        id: Math.random().toString(36).substr(2, 9),
        studentId: currentUser!.id,
        classId: activeSession.classId,
        sessionId: activeSession.id,
        timestamp: new Date().toISOString(),
        status: 'PRESENT',
        location: { lat: 40.7128, lng: -74.0060 } // Mock location
      };

      addAttendance(newRecord);
      setResult('SUCCESS');
      setScanning(false);
    }, 2000);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Mark Attendance</h2>
        <p className="text-slate-400">Scan the QR code displayed by your teacher</p>
      </div>

      <div className="glass p-10 rounded-[2.5rem] border border-white/5 flex flex-col items-center">
        <AnimatePresence mode="wait">
          {!scanning && !result && (
            <motion.div 
              key="initial"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="flex flex-col items-center"
            >
              <div className="w-64 h-64 border-2 border-dashed border-white/20 rounded-3xl flex items-center justify-center mb-10 relative group">
                <div className="absolute inset-0 bg-brand-blue/5 rounded-3xl group-hover:bg-brand-blue/10 transition-colors" />
                <Camera className="w-16 h-16 text-slate-500 group-hover:text-brand-blue transition-colors" />
                {/* Scanner corners */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-brand-blue rounded-tl-xl" />
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-brand-blue rounded-tr-xl" />
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-brand-blue rounded-bl-xl" />
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-brand-blue rounded-br-xl" />
              </div>

              <div className="space-y-4 w-full">
                <div className="flex items-center gap-3 text-slate-400 text-sm px-4 py-3 bg-white/5 rounded-xl border border-white/5">
                  <ShieldCheck className="w-5 h-5 text-brand-electric" />
                  <span>Secure session verification active</span>
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-sm px-4 py-3 bg-white/5 rounded-xl border border-white/5">
                  <MapPin className="w-5 h-5 text-brand-electric" />
                  <span>GPS location check enabled</span>
                </div>

                <button 
                  onClick={simulateScan}
                  className="w-full bg-brand-blue hover:bg-brand-blue/90 text-white font-bold py-4 rounded-xl shadow-xl shadow-brand-blue/20 transition-all active:scale-[0.98] mt-6 flex items-center justify-center gap-2"
                >
                  <QrCode className="w-5 h-5" />
                  Launch Scanner
                </button>
              </div>
            </motion.div>
          )}

          {scanning && (
            <motion.div 
              key="scanning"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center py-10"
            >
              <div className="w-20 h-20 border-4 border-brand-blue/30 border-t-brand-blue rounded-full animate-spin mb-6" />
              <p className="text-xl font-bold text-white mb-2">Verifying...</p>
              <p className="text-slate-400">Authenticating session and location</p>
            </motion.div>
          )}

          {result === 'SUCCESS' && (
            <motion.div 
              key="success"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center py-10 text-center"
            >
              <div className="w-24 h-24 bg-emerald-500/20 rounded-full flex items-center justify-center mb-6">
                <CheckCircle2 className="w-12 h-12 text-emerald-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">Attendance Marked!</h3>
              <p className="text-slate-400 mb-8">Your presence has been successfully logged.</p>
              <button 
                onClick={() => setResult(null)}
                className="px-8 py-3 bg-white/5 hover:bg-white/10 text-white font-semibold rounded-xl transition-colors"
              >
                Back to Dashboard
              </button>
            </motion.div>
          )}

          {(result === 'ERROR' || result === 'ALREADY_MARKED') && (
            <motion.div 
              key="error"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center py-10 text-center"
            >
              <div className="w-24 h-24 bg-red-500/20 rounded-full flex items-center justify-center mb-6">
                <AlertCircle className="w-12 h-12 text-red-400" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">
                {result === 'ALREADY_MARKED' ? 'Already Marked' : 'Session Not Found'}
              </h3>
              <p className="text-slate-400 mb-8 max-w-xs mx-auto">
                {result === 'ALREADY_MARKED' 
                  ? 'You have already marked your attendance for this session.' 
                  : 'Please ensure your teacher has started the session and try again.'}
              </p>
              <button 
                onClick={() => setResult(null)}
                className="px-8 py-3 bg-brand-blue text-white font-semibold rounded-xl transition-colors"
              >
                Try Again
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ScanQR;
