import { useStore } from '../store/useStore';
import Layout from '../components/layout/Layout';
import { BookOpen, Plus, Search, Users, Clock, ArrowRight, MoreHorizontal, Calendar, X } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const Classes = () => {
  const { classes, users, addClass, currentUser } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newClassCode, setNewClassCode] = useState('');

  const handleCreateClass = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassName || !newClassCode) return;

    addClass({
      id: Math.random().toString(36).substr(2, 9),
      name: newClassName,
      code: newClassCode,
      teacherId: currentUser?.id || 'harsh',
      students: ['raman'] // Default student for demo
    });

    setNewClassName('');
    setNewClassCode('');
    setIsModalOpen(false);
  };

  return (
    <Layout>
      <div className="space-y-6 md:space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-black text-white tracking-tight">Course Deployment</h2>
            <p className="text-zinc-500 text-sm font-medium">Academic session orchestration and management</p>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl shadow-blue-500/20 w-full sm:w-auto"
          >
            <Plus className="w-5 h-5" />
            Deploy New Course
          </button>
        </div>

        <AnimatePresence>
          {isModalOpen && (
            <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsModalOpen(false)}
                className="absolute inset-0 bg-brand-900/80 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative glass-dark p-8 md:p-10 rounded-[2.5rem] border border-white/10 w-full max-w-md shadow-2xl"
              >
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="absolute top-8 right-8 p-2 text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
                <h3 className="text-2xl font-bold text-white mb-8">Course Deployment</h3>
                <form onSubmit={handleCreateClass} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Subject Title</label>
                    <input 
                      type="text" 
                      value={newClassName}
                      onChange={(e) => setNewClassName(e.target.value)}
                      placeholder="e.g. Distributed Systems"
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Institutional Code</label>
                    <input 
                      type="text" 
                      value={newClassCode}
                      onChange={(e) => setNewClassCode(e.target.value)}
                      placeholder="e.g. CS501"
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                      required
                    />
                  </div>
                  <button 
                    type="submit"
                    className="w-full bg-brand-blue hover:bg-brand-blue/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-brand-blue/20 transition-all active:scale-[0.98] mt-4"
                  >
                    Confirm Deployment
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <div className="relative group max-w-2xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600 group-focus-within:text-brand-blue transition-colors" />
          <input 
            type="text" 
            placeholder="Filter courses by nomenclature, code or faculty..." 
            className="w-full bg-zinc-900 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30 transition-all shadow-inner"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {classes.map((cls) => {
            const teacher = users.find(u => u.id === cls.teacherId);
            return (
              <div key={cls.id} className="glass-dark p-8 rounded-[2.5rem] border border-white/5 group hover:border-brand-blue/30 transition-all flex flex-col shadow-lg hover:shadow-brand-blue/5">
                <div className="flex items-start justify-between mb-8">
                  <div className="w-14 h-14 bg-zinc-800 rounded-2xl flex items-center justify-center text-brand-blue border border-white/5 shadow-inner group-hover:scale-110 transition-transform">
                    <BookOpen className="w-7 h-7" />
                  </div>
                  <button className="p-2 text-zinc-600 hover:text-white transition-colors">
                    <MoreHorizontal className="w-6 h-6" />
                  </button>
                </div>

                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-[10px] font-black tracking-widest text-brand-blue bg-brand-blue/10 px-2.5 py-1 rounded-lg uppercase border border-brand-blue/20">{cls.code}</span>
                  </div>
                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-brand-electric transition-colors">{cls.name}</h3>
                  <div className="flex items-center gap-3 text-zinc-500">
                    <div className="w-6 h-6 rounded-lg bg-zinc-800 flex items-center justify-center text-[10px] font-black border border-white/5">
                      {teacher?.name.charAt(0)}
                    </div>
                    <span className="text-xs font-bold uppercase tracking-widest">{teacher?.name}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-white/[0.02] rounded-2xl p-4 border border-white/5">
                    <div className="flex items-center gap-2 text-zinc-600 mb-1.5">
                      <Users className="w-3.5 h-3.5" />
                      <span className="text-[8px] font-black uppercase tracking-widest">Enrollment</span>
                    </div>
                    <p className="text-lg font-bold text-white">{cls.students.length}</p>
                  </div>
                  <div className="bg-white/[0.02] rounded-2xl p-4 border border-white/5">
                    <div className="flex items-center gap-2 text-zinc-600 mb-1.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span className="text-[8px] font-black uppercase tracking-widest">Schedule</span>
                    </div>
                    <p className="text-xs font-bold text-white">Mon, Wed • 09:00</p>
                  </div>
                </div>

                <div className="mt-auto pt-6 border-t border-white/5 flex items-center justify-between">
                  <div className="flex -space-x-2">
                    {cls.students.slice(0, 3).map((sId, i) => {
                      const s = users.find(u => u.id === sId);
                      return (
                        <div key={i} title={s?.name} className="w-8 h-8 rounded-xl bg-zinc-800 border-2 border-[#09090b] flex items-center justify-center text-[8px] font-black text-zinc-500">
                          {s?.name.charAt(0)}
                        </div>
                      );
                    })}
                    {cls.students.length > 3 && (
                      <div className="w-8 h-8 rounded-xl bg-brand-blue/10 border-2 border-[#09090b] flex items-center justify-center text-[8px] font-black text-brand-blue border-brand-blue/20">
                        +{cls.students.length - 3}
                      </div>
                    )}
                  </div>
                  
                  <button className="flex items-center gap-1.5 text-brand-blue font-black text-[10px] uppercase tracking-widest group/btn hover:text-brand-electric transition-colors">
                    Registry
                    <ArrowRight className="w-3 h-3 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
          
          <button 
            onClick={() => setIsModalOpen(true)}
            className="glass-dark border-2 border-dashed border-white/5 rounded-[2.5rem] p-8 flex flex-col items-center justify-center text-zinc-600 hover:text-brand-blue hover:border-brand-blue/30 hover:bg-white/[0.01] transition-all min-h-[380px] group"
          >
            <div className="w-16 h-16 rounded-[2rem] bg-white/[0.02] flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Calendar className="w-8 h-8" />
            </div>
            <p className="text-sm font-black uppercase tracking-widest">New Deployment</p>
            <p className="text-[10px] mt-2 font-medium">Add subjects to institutional catalog</p>
          </button>
        </div>
      </div>
    </Layout>
  );
};

export default Classes;
