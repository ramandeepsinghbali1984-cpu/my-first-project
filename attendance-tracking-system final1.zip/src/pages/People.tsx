import { useStore, UserRole } from '../store/useStore';
import Layout from '../components/layout/Layout';
import { UserPlus, Search, Filter, Mail, Shield, User as UserIcon, MoreVertical, Trash2, Edit2, X } from 'lucide-react';
import { cn } from '../utils/cn';
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const People = () => {
  const { users, addUser, deleteUser } = useStore();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('STUDENT');

  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName || !newEmail) return;

    addUser({
      id: Math.random().toString(36).substr(2, 9),
      name: newName,
      email: newEmail,
      role: newRole
    });

    setNewName('');
    setNewEmail('');
    setIsModalOpen(false);
  };

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'ADMIN': return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'TEACHER': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      default: return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
    }
  };

  return (
    <Layout>
      <div className="space-y-6 md:space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-black text-white tracking-tight">Registry Directory</h2>
            <p className="text-zinc-500 text-sm font-medium">Institutional user database and access control</p>
          </div>
          <button 
            onClick={() => setIsModalOpen(true)}
            className="flex items-center justify-center gap-3 px-8 py-4 bg-gradient-to-br from-blue-600 to-indigo-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl shadow-blue-500/20 w-full sm:w-auto"
          >
            <UserPlus className="w-5 h-5" />
            Enroll New User
          </button>
        </div>

        <AnimatePresence>
          {isModalOpen && (
            <div className="fixed inset-0 z-[150] flex items-center justify-center p-4">
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setIsModalOpen(false)}
                className="absolute inset-0 bg-brand-900/80 backdrop-blur-sm"
              />
              <motion.div 
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative glass-dark p-8 md:p-10 rounded-[2.5rem] border border-white/10 w-full max-w-md shadow-2xl"
              >
                <button 
                  onClick={() => setIsModalOpen(false)}
                  className="absolute top-8 right-8 p-2 text-zinc-500 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
                <h3 className="text-2xl font-bold text-white mb-8">User Enrollment</h3>
                <form onSubmit={handleAddUser} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Full Identity</label>
                    <input 
                      type="text" 
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="e.g. Ramandeep Kaur"
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Institutional Email</label>
                    <input 
                      type="email" 
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="e.g. raman@school.edu"
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest px-1">Access Tier</label>
                    <select 
                      value={newRole}
                      onChange={(e) => setNewRole(e.target.value as UserRole)}
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                    >
                      <option value="STUDENT">Student</option>
                      <option value="TEACHER">Teacher</option>
                      <option value="ADMIN">Administrator</option>
                    </select>
                  </div>
                  <button 
                    type="submit"
                    className="w-full bg-brand-blue hover:bg-brand-blue/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-brand-blue/20 transition-all active:scale-[0.98] mt-4"
                  >
                    Confirm Enrollment
                  </button>
                </form>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
          <div className="glass-dark p-6 rounded-2xl border border-white/5 flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-500/10 rounded-xl flex items-center justify-center text-indigo-400 border border-indigo-500/20">
              <UserIcon className="w-6 h-6" />
            </div>
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Students</p>
              <h3 className="text-2xl font-bold text-white">{users.filter(u => u.role === 'STUDENT').length}</h3>
            </div>
          </div>
          <div className="glass-dark p-6 rounded-2xl border border-white/5 flex items-center gap-4">
            <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center text-emerald-400 border border-emerald-500/20">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Teachers</p>
              <h3 className="text-2xl font-bold text-white">{users.filter(u => u.role === 'TEACHER').length}</h3>
            </div>
          </div>
          <div className="glass-dark p-6 rounded-2xl border border-white/5 flex items-center gap-4">
            <div className="w-12 h-12 bg-purple-500/10 rounded-xl flex items-center justify-center text-purple-400 border border-purple-500/20">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest">Admins</p>
              <h3 className="text-2xl font-bold text-white">{users.filter(u => u.role === 'ADMIN').length}</h3>
            </div>
          </div>
        </div>

        <div className="glass-dark rounded-[2.5rem] border border-white/5 overflow-hidden">
          <div className="p-6 md:p-8 border-b border-white/5 bg-white/[0.01] flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            <div className="relative flex-1 max-w-xl">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-600" />
              <input 
                type="text" 
                placeholder="Search by name, email or institutional ID..." 
                className="w-full bg-zinc-900 border border-white/10 rounded-2xl py-3.5 pl-12 pr-4 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30 transition-all"
              />
            </div>
            <div className="flex items-center gap-3 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
              <button className="flex items-center gap-2 px-5 py-2.5 bg-white/5 text-zinc-300 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-white/10 transition-colors border border-white/5">
                <Filter className="w-4 h-4" />
                Advanced Filters
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left min-w-[800px]">
              <thead>
                <tr className="text-zinc-500 text-[10px] font-black uppercase tracking-widest border-b border-white/5">
                  <th className="px-8 py-6">Identity</th>
                  <th className="px-8 py-6">Access Tier</th>
                  <th className="px-8 py-6">Credentials</th>
                  <th className="px-8 py-6">Department</th>
                  <th className="px-8 py-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {users.map((user) => (
                  <tr key={user.id} className="group hover:bg-white/[0.01] transition-all">
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-4">
                        <div className="w-11 h-11 rounded-2xl bg-zinc-800 flex items-center justify-center border border-white/10 overflow-hidden shadow-inner group-hover:scale-110 transition-transform">
                          {user.avatar ? (
                            <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
                          ) : (
                            <UserIcon className="w-5 h-5 text-zinc-600 group-hover:text-brand-blue transition-colors" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white group-hover:text-brand-electric transition-colors">{user.name}</p>
                          <p className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest">ID: #{Math.floor(10000 + Math.random() * 90000)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={cn(
                        "px-3 py-1 rounded-lg text-[10px] font-black tracking-widest uppercase border",
                        getRoleColor(user.role)
                      )}>
                        {user.role}
                      </span>
                    </td>
                    <td className="px-8 py-5">
                      <div className="flex items-center gap-2.5 text-zinc-500 group-hover:text-zinc-300 transition-colors">
                        <Mail className="w-4 h-4" />
                        <span className="text-xs font-semibold">{user.email}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Faculty of Computing</span>
                    </td>
                    <td className="px-8 py-5 text-right">
                      <div className="flex items-center justify-end gap-1">
                        <button className="p-2.5 text-zinc-600 hover:text-white hover:bg-white/5 rounded-xl transition-all">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => deleteUser(user.id)}
                          className="p-2.5 text-zinc-600 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="p-10 border-t border-white/5 flex items-center justify-center">
            <button className="text-[10px] font-black uppercase tracking-widest text-brand-blue hover:text-brand-electric transition-colors flex items-center gap-2">
              Browse More Records
              <MoreVertical className="w-4 h-4 rotate-90" />
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default People;
