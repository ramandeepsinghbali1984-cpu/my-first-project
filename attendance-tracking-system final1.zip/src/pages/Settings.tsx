import { useStore } from '../store/useStore';
import Layout from '../components/layout/Layout';
import { User, Bell, Shield, Smartphone, Globe, Save, Camera, Check } from 'lucide-react';
import { useState } from 'react';

const Settings = () => {
  const { currentUser, updateUser } = useStore();
  const [saved, setSaved] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  
  const [name, setName] = useState(currentUser?.name || '');
  const [email, setEmail] = useState(currentUser?.email || '');
  const [bio, setBio] = useState('Passionate educator dedicated to academic excellence.');
  
  const [notifs, setNotifs] = useState({
    lowAttendance: true,
    dailySummary: true,
    systemAnnouncements: true,
    directMessages: true
  });

  const handleSave = () => {
    if (currentUser) {
      updateUser(currentUser.id, { name, email });
    }
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const tabs = [
    { id: 'profile', name: 'Profile Information', icon: User },
    { id: 'notifications', name: 'Notifications', icon: Bell },
    { id: 'security', name: 'Security & Privacy', icon: Shield },
    { id: 'devices', name: 'Connected Devices', icon: Smartphone },
    { id: 'language', name: 'Language & Regional', icon: Globe },
  ];

  return (
    <Layout>
      <div className="max-w-4xl mx-auto space-y-8 pb-12">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-white">Account Settings</h2>
            <p className="text-slate-400">Manage your profile and preferences</p>
          </div>
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 px-6 py-3 bg-brand-blue text-white rounded-xl font-bold hover:bg-brand-blue/90 transition-all shadow-lg shadow-brand-blue/20"
          >
            {saved ? <Check className="w-5 h-5" /> : <Save className="w-5 h-5" />}
            {saved ? 'Settings Saved' : 'Save Changes'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <nav className="flex md:flex-col gap-1 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
            {tabs.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex-shrink-0 flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === item.id ? 'bg-brand-blue/10 text-brand-blue' : 'text-slate-400 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span className="whitespace-nowrap">{item.name}</span>
              </button>
            ))}
          </nav>

          <div className="md:col-span-3 space-y-8">
            {/* Profile Section */}
            {activeTab === 'profile' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/5">
                <h3 className="text-xl font-bold text-white mb-8">Profile Details</h3>
                
                <div className="flex flex-col md:flex-row gap-10">
                  <div className="relative group self-center md:self-start">
                    <div className="w-32 h-32 rounded-[2rem] bg-slate-800 border border-white/10 flex items-center justify-center overflow-hidden">
                      <User className="w-12 h-12 text-slate-600" />
                    </div>
                    <button className="absolute -bottom-2 -right-2 w-10 h-10 bg-brand-blue rounded-xl flex items-center justify-center border-4 border-brand-900 text-white shadow-xl hover:scale-110 transition-transform">
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex-1 space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Full Name</label>
                        <input 
                          type="text" 
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Email Address</label>
                        <input 
                          type="email" 
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Bio / Institution Notes</label>
                      <textarea 
                        rows={4}
                        value={bio}
                        onChange={(e) => setBio(e.target.value)}
                        placeholder="Enter a brief description..."
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30 resize-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Notifications Section */}
            {activeTab === 'notifications' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/5">
                <h3 className="text-xl font-bold text-white mb-8">Notification Preferences</h3>
                <div className="space-y-6">
                  {[
                    { id: 'lowAttendance', title: 'Low Attendance Alerts', desc: 'Receive a notification when attendance drops below 75%' },
                    { id: 'dailySummary', title: 'Daily Summary', desc: 'A daily digest of all scanned attendance sessions' },
                    { id: 'systemAnnouncements', title: 'System Announcements', desc: 'Stay updated with new features and maintenance' },
                    { id: 'directMessages', title: 'Direct Messages', desc: 'When teachers or admins send you a direct message' },
                  ].map((item) => (
                    <div key={item.id} className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-bold text-white">{item.title}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
                      </div>
                      <button 
                        onClick={() => setNotifs(prev => ({ ...prev, [item.id]: !prev[item.id as keyof typeof notifs] }))}
                        className={`w-12 h-6 rounded-full transition-colors relative ${notifs[item.id as keyof typeof notifs] ? 'bg-brand-blue' : 'bg-slate-700'}`}
                      >
                        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${notifs[item.id as keyof typeof notifs] ? 'right-1' : 'left-1'}`} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Security Tab */}
            {activeTab === 'security' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/5 space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Security & Privacy</h3>
                  <p className="text-sm text-slate-400">Manage your password and account security</p>
                </div>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Current Password</label>
                      <input type="password" placeholder="••••••••" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">New Password</label>
                      <input type="password" placeholder="••••••••" className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30" />
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-brand-blue/20 rounded-xl flex items-center justify-center text-brand-blue">
                        <Shield className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-white">Two-Factor Authentication</p>
                        <p className="text-xs text-slate-500">Add an extra layer of security to your account</p>
                      </div>
                    </div>
                    <button className="px-4 py-2 bg-brand-blue text-white rounded-lg text-xs font-bold">Enable</button>
                  </div>
                </div>
              </div>
            )}

            {/* Devices Tab */}
            {activeTab === 'devices' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/5 space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Connected Devices</h3>
                  <p className="text-sm text-slate-400">Devices currently logged into your account</p>
                </div>
                <div className="space-y-4">
                  {[
                    { name: 'MacBook Pro 14"', os: 'macOS Monterey', lastActive: 'Active now', icon: Globe },
                    { name: 'iPhone 13 Pro', os: 'iOS 15.4', lastActive: '2 hours ago', icon: Smartphone },
                  ].map((device, i) => (
                    <div key={i} className="flex items-center justify-between p-4 bg-white/5 rounded-2xl border border-white/5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center text-slate-400">
                          <device.icon className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">{device.name}</p>
                          <p className="text-xs text-slate-500">{device.os} • {device.lastActive}</p>
                        </div>
                      </div>
                      <button className="text-xs font-bold text-red-400 hover:text-red-300">Revoke</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Language Tab */}
            {activeTab === 'language' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/5 space-y-8">
                <div>
                  <h3 className="text-xl font-bold text-white mb-2">Language & Regional</h3>
                  <p className="text-sm text-slate-400">Customize your language and timezone</p>
                </div>
                <div className="space-y-6">
                   <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Display Language</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none">
                      <option>English (United States)</option>
                      <option>Hindi (India)</option>
                      <option>Spanish (ES)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500 uppercase tracking-widest px-1">Timezone</label>
                    <select className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none">
                      <option>(GMT+05:30) India Standard Time</option>
                      <option>(GMT-08:00) Pacific Time</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'profile' && (
              <div className="glass p-8 rounded-[2.5rem] border border-white/10 border-red-500/10">
                <h3 className="text-xl font-bold text-white mb-2">Danger Zone</h3>
                <p className="text-xs text-slate-500 mb-8">Permanently delete your account and all associated data.</p>
                <button className="px-6 py-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-xl text-sm font-bold hover:bg-red-500 hover:text-white transition-all">
                  Delete My Account
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Settings;
