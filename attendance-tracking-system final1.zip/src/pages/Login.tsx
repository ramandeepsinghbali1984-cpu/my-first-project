import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { UserRole, useStore } from '../store/useStore';
import { QrCode, Mail, Lock, CheckCircle2, ShieldCheck, User as UserIcon, GraduationCap, AlertCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const Login = () => {
  const [role, setRole] = useState<UserRole>('STUDENT');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useStore();
  const navigate = useNavigate();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      const result = login(email, password, role);
      
      if (result.success) {
        setIsLoading(false);
        navigate('/');
      } else {
        setError(result.message || 'Login failed');
        setIsLoading(false);
      }
    }, 800);
  };

  const roles = [
    { id: 'STUDENT', label: 'Student', icon: GraduationCap, color: 'text-indigo-400', bg: 'bg-indigo-400/10', border: 'border-indigo-400/20' },
    { id: 'TEACHER', label: 'Teacher', icon: UserIcon, color: 'text-emerald-400', bg: 'bg-emerald-400/10', border: 'border-emerald-400/20' },
    { id: 'ADMIN', label: 'Administrator', icon: ShieldCheck, color: 'text-zinc-400', bg: 'bg-zinc-400/10', border: 'border-zinc-400/20' },
  ];

  return (
    <div className="min-h-screen bg-[#09090b] flex items-center justify-center p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 -left-1/4 w-1/2 h-1/2 bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-0 -right-1/4 w-1/2 h-1/2 bg-indigo-600/10 blur-[120px] rounded-full pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md relative z-10"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-br from-brand-blue to-indigo-600 rounded-[1.25rem] flex items-center justify-center shadow-2xl shadow-blue-500/20 mx-auto mb-6 transform -rotate-6">
            <QrCode className="text-white w-8 h-8" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2">Attendify</h1>
          <p className="text-zinc-500 text-sm font-bold uppercase tracking-widest">Enterprise Attendance Cloud</p>
        </div>

        <div className="bg-zinc-900/50 p-8 md:p-10 rounded-[2.5rem] border border-white/5 shadow-2xl backdrop-blur-3xl relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-white/[0.02] to-transparent pointer-events-none" />
          
          <div className="grid grid-cols-3 gap-3 mb-10">
            {roles.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => {
                  setRole(r.id as UserRole);
                  setError('');
                }}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border transition-all duration-300 group ${
                  role === r.id 
                    ? `bg-white/5 ${r.border} border-opacity-100` 
                    : 'border-transparent hover:bg-white/5'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-2 transition-transform group-hover:scale-110 ${r.bg} ${r.color}`}>
                  <r.icon className="w-5 h-5" />
                </div>
                <span className={`text-[8px] font-black uppercase tracking-widest ${role === r.id ? 'text-white' : 'text-zinc-500'}`}>
                  {r.label}
                </span>
                {role === r.id && (
                  <motion.div layoutId="activeRole" className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2" />
                )}
              </button>
            ))}
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-500 dark:text-red-400 text-xs font-bold flex items-center gap-2"
              >
                <AlertCircle className="w-4 h-4 shrink-0" />
                {error}
              </motion.div>
            )}
            <div className="space-y-4">
              <div className="relative group">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-blue transition-colors" />
                <input
                  type="email"
                  placeholder="Email Address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50/5 dark:bg-slate-900/50 border border-slate-200 dark:border-white/5 rounded-xl py-3.5 pl-12 pr-4 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30 focus:border-brand-blue/40 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                />
              </div>
              <div className="relative group">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-brand-blue transition-colors" />
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50/5 dark:bg-slate-900/50 border border-slate-200 dark:border-white/5 rounded-xl py-3.5 pl-12 pr-4 text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30 focus:border-brand-blue/40 transition-all placeholder:text-slate-400 dark:placeholder:text-slate-600"
                />
              </div>
            </div>

            <div className="flex items-center justify-between px-1">
              <label className="flex items-center gap-2 cursor-pointer group">
                <input type="checkbox" className="hidden" />
                <div className="w-4 h-4 rounded border border-white/20 group-hover:border-brand-blue transition-colors flex items-center justify-center">
                  <CheckCircle2 className="w-3 h-3 text-brand-blue hidden" />
                </div>
                <span className="text-sm text-slate-400 group-hover:text-slate-300">Remember me</span>
              </label>
              <button type="button" className="text-sm text-brand-blue font-medium hover:text-brand-electric transition-colors">
                Forgot password?
              </button>
            </div>

            <button
              disabled={isLoading}
              className="w-full bg-brand-blue hover:bg-brand-blue/90 text-white font-bold py-4 rounded-xl shadow-lg shadow-brand-blue/25 transition-all active:scale-[0.98] disabled:opacity-70 flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                'Sign In'
              )}
            </button>
          </form>
        </div>

        <p className="mt-8 text-center text-zinc-600 text-[10px] font-black uppercase tracking-[0.2em]">
          Institutional Access Only
        </p>
        <p className="mt-2 text-center text-zinc-700 text-[8px] font-bold">
          © 2024 Attendify Cloud Solutions • Secure Layer Active
        </p>
      </motion.div>
    </div>
  );
};

export default Login;
