import { useState, useEffect } from 'react';
import { useStore, Session } from '../store/useStore';
import StatCard from '../components/common/StatCard';
import { QrCode, Users, CheckCircle, Clock, Play, Square, MoreHorizontal, UserX, BookOpen } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';

const TeacherDashboard = () => {
  const { currentUser, classes, sessions, createSession, endSession, attendance, users } = useStore();
  const [activeSession, setActiveSession] = useState<Session | null>(null);
  const [selectedClassId, setSelectedClassId] = useState('');

  useEffect(() => {
    const active = sessions.find(s => s.isActive && s.teacherId === currentUser?.id);
    setActiveSession(active || null);
    if (active) setSelectedClassId(active.classId);
  }, [sessions, currentUser]);

  const teacherClasses = classes.filter(c => c.teacherId === currentUser?.id);

  const startNewSession = () => {
    if (!selectedClassId) return;
    
    const newSession: Session = {
      id: Math.random().toString(36).substr(2, 9),
      classId: selectedClassId,
      teacherId: currentUser!.id,
      startTime: new Date().toISOString(),
      endTime: new Date(Date.now() + 10 * 60000).toISOString(),
      qrCode: `session-${Math.random().toString(36).substr(2, 9)}`,
      isActive: true,
    };
    
    createSession(newSession);
  };

  const currentClassAttendance = attendance.filter(a => a.sessionId === activeSession?.id);
  const selectedClass = classes.find(c => c.id === (activeSession?.classId || selectedClassId));
  const classStudents = selectedClass ? users.filter(u => selectedClass.students.includes(u.id)) : [];

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-zinc-100">Teacher Hub</h2>
          <p className="text-slate-500 dark:text-zinc-500 text-sm">Monitor your active class sessions</p>
        </div>
        <Link to="/classes" className="bg-brand-blue hover:bg-brand-blue/90 text-white px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-blue/20 w-full sm:w-auto">
          <BookOpen className="w-4 h-4" />
          Manage Classes
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatCard title="Total Enrolled" value={classStudents.length} icon={Users} color="bg-indigo-500" />
        <StatCard title="Present Now" value={currentClassAttendance.length} icon={CheckCircle} color="bg-emerald-500" />
        <StatCard title="Class Avg." value="88%" icon={Clock} color="bg-purple-500" />
        <StatCard title="At Risk" value="3" icon={UserX} color="bg-amber-500" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* QR Session Controller */}
        <div className="xl:col-span-1 glass-dark p-6 md:p-10 rounded-[2.5rem] border border-white/5 flex flex-col items-center justify-center text-center">
          {activeSession ? (
            <>
              <div className="mb-8 p-6 bg-white rounded-[2rem] shadow-2xl shadow-indigo-500/10 w-fit">
                <QRCodeSVG value={activeSession.qrCode} size={180} level="H" className="max-w-full" />
              </div>
              <h3 className="text-xl font-bold text-white mb-1">Session Active</h3>
              <p className="text-brand-electric font-bold text-sm uppercase tracking-widest mb-8">{selectedClass?.name}</p>
              
              <div className="w-full space-y-4">
                <div className="flex justify-between text-[10px] font-black uppercase tracking-widest text-zinc-500 px-2">
                  <span>Time Remaining</span>
                  <span className="text-brand-electric">7:42 Left</span>
                </div>
                <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                  <div className="bg-brand-blue h-full w-2/3 transition-all" />
                </div>
                <button 
                  onClick={() => endSession(activeSession.id)}
                  className="w-full mt-6 bg-red-500/10 hover:bg-red-500/20 text-red-500 font-bold py-4 rounded-xl transition-all flex items-center justify-center gap-2 text-sm"
                >
                  <Square className="w-4 h-4 fill-current" />
                  Terminate Session
                </button>
              </div>
            </>
          ) : (
            <>
              <div className="w-20 h-20 bg-white/5 rounded-[2rem] flex items-center justify-center mb-8">
                <QrCode className="w-10 h-10 text-zinc-700" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">Initialize Session</h3>
              <p className="text-zinc-500 mb-10 text-sm leading-relaxed max-w-[240px]">Select a class to generate an attendance QR code for your students.</p>
              
              <select 
                value={selectedClassId}
                onChange={(e) => setSelectedClassId(e.target.value)}
                className="w-full bg-zinc-900 border border-white/10 rounded-xl py-3.5 px-4 mb-4 text-white text-sm focus:outline-none focus:ring-2 focus:ring-brand-blue/30"
              >
                <option value="">Choose your class...</option>
                {teacherClasses.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>

              <button 
                onClick={startNewSession}
                disabled={!selectedClassId}
                className="w-full bg-brand-blue hover:bg-brand-blue/90 disabled:opacity-30 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl shadow-xl shadow-brand-blue/20 transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-current" />
                Generate QR Code
              </button>
            </>
          )}
        </div>

        {/* Real-time Attendance List */}
        <div className="xl:col-span-2 glass-dark p-6 md:p-8 rounded-[2.5rem] border border-white/5 overflow-hidden">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-white flex items-center gap-3">
              Live Attendance Registry
              <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" />
            </h3>
            <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400 bg-emerald-400/10 px-3 py-1 rounded-full">
              Real-time
            </span>
          </div>

          <div className="overflow-x-auto -mx-6 md:mx-0">
            <table className="w-full text-left min-w-[500px]">
              <thead>
                <tr className="text-zinc-500 text-[10px] uppercase tracking-widest border-b border-white/5">
                  <th className="px-6 pb-4 font-bold">Student Identity</th>
                  <th className="px-6 pb-4 font-bold">Timestamp</th>
                  <th className="px-6 pb-4 font-bold">Verification</th>
                  <th className="px-6 pb-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {currentClassAttendance.length > 0 ? (
                  currentClassAttendance.map((rec) => {
                    const student = users.find(u => u.id === rec.studentId);
                    return (
                      <tr key={rec.id} className="group hover:bg-white/[0.01]">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-xl bg-zinc-800 flex items-center justify-center text-xs font-bold text-zinc-400 border border-white/5">
                              {student?.name.charAt(0)}
                            </div>
                            <span className="font-bold text-zinc-100 text-sm">{student?.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-zinc-500 text-sm">{format(new Date(rec.timestamp), 'HH:mm:ss')}</td>
                        <td className="px-6 py-4">
                          <span className="bg-emerald-500/10 text-emerald-400 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest border border-emerald-500/20">
                            Verified
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="p-2 text-zinc-500 hover:text-white transition-colors">
                            <MoreHorizontal className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={4} className="py-20 text-center text-zinc-600 text-sm italic">
                      System standby. Awaiting student scans...
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Alerts & Manual Overrides */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-dark p-8 rounded-[2.5rem] border border-white/5">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <UserX className="text-amber-500 w-5 h-5" />
              Critical Watchlist
            </h3>
            <button className="text-[10px] font-black text-brand-blue hover:underline uppercase tracking-widest">Broadcast Alerts</button>
          </div>
          <div className="space-y-4">
            {[
              { name: 'Emily Brown', percentage: '68%', status: 'Critical' },
              { name: 'Mark Wilson', percentage: '72%', status: 'Warning' },
            ].map((student, i) => (
              <div key={i} className="flex items-center justify-between p-4 bg-white/[0.02] rounded-2xl border border-white/5">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold ${student.status === 'Critical' ? 'bg-red-500/10 text-red-500' : 'bg-amber-500/10 text-amber-500'}`}>
                    {student.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white">{student.name}</p>
                    <p className="text-[10px] text-zinc-500 font-medium uppercase tracking-widest">{student.status}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-black ${student.status === 'Critical' ? 'text-red-500' : 'text-amber-500'}`}>{student.percentage}</p>
                  <button className="text-[10px] font-bold text-brand-blue hover:text-brand-electric uppercase tracking-tighter">View Detail</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass-dark p-8 rounded-[2.5rem] border border-white/5">
          <h3 className="text-lg font-bold text-white mb-4">Override Protocols</h3>
          <p className="text-sm text-zinc-500 mb-8 leading-relaxed">Manually adjust status for students with validated exceptions.</p>
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <select className="bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30">
                <option>Select Student...</option>
                {classStudents.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
              <select className="bg-zinc-900 border border-white/10 rounded-xl px-4 py-3.5 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brand-blue/30">
                <option>New Status...</option>
                <option>Present</option>
                <option>Excused</option>
              </select>
            </div>
            <button className="w-full bg-white/5 hover:bg-white/10 text-zinc-300 font-bold py-4 rounded-xl border border-white/10 transition-all text-sm">
              Update Database Record
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherDashboard;
