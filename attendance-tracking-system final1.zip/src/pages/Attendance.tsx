import { useStore } from '../store/useStore';
import Layout from '../components/layout/Layout';
import { Calendar as CalendarIcon, Filter, Search, Download, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '../utils/cn';

const Attendance = () => {
  const { currentUser, attendance, users, classes } = useStore();

  const getFilteredAttendance = () => {
    if (currentUser?.role === 'STUDENT') {
      return attendance.filter(a => a.studentId === currentUser.id);
    }
    return attendance;
  };

  const displayRecords = getFilteredAttendance();

  return (
    <Layout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-white">Attendance History</h2>
            <p className="text-slate-400">View and manage detailed attendance logs</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 px-4 py-2.5 glass rounded-xl text-sm font-semibold hover:bg-white/10 transition-colors">
              <Filter className="w-4 h-4" />
              Filter
            </button>
            <button className="flex items-center gap-2 px-4 py-2.5 bg-brand-blue text-white rounded-xl text-sm font-semibold hover:bg-brand-blue/90 transition-all shadow-lg shadow-brand-blue/20">
              <Download className="w-4 h-4" />
              Export CSV
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900/40 rounded-[2rem] border border-slate-200 dark:border-white/5 overflow-hidden shadow-sm">
          <div className="p-6 border-b border-slate-200 dark:border-white/5 bg-slate-50/50 dark:bg-white/[0.01] flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="Filter history..." 
                className="w-full bg-white dark:bg-slate-950 border border-slate-200 dark:border-white/10 rounded-xl py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              />
            </div>
            <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 scrollbar-none">
              {['All', 'Present', 'Absent', 'Late'].map((status) => (
                <button 
                  key={status}
                  className={cn(
                    "px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap",
                    status === 'All' ? "bg-blue-600 text-white shadow-md shadow-blue-600/20" : "bg-slate-100 dark:bg-white/5 text-slate-500 dark:text-slate-400 hover:text-blue-600"
                  )}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-500 text-xs uppercase tracking-wider border-b border-white/5">
                  <th className="px-6 py-4 font-bold">Student</th>
                  <th className="px-6 py-4 font-bold">Class</th>
                  <th className="px-6 py-4 font-bold">Date & Time</th>
                  <th className="px-6 py-4 font-bold">Location</th>
                  <th className="px-6 py-4 font-bold">Status</th>
                  <th className="px-6 py-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {displayRecords.length > 0 ? (
                  displayRecords.map((record) => {
                    const student = users.find(u => u.id === record.studentId);
                    const cls = classes.find(c => c.id === record.classId);
                    return (
                      <tr key={record.id} className="group hover:bg-white/[0.02] transition-colors">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-slate-700 to-slate-800 flex items-center justify-center text-slate-300 font-bold border border-white/5">
                              {student?.name.charAt(0)}
                            </div>
                            <div>
                              <p className="text-sm font-bold text-white leading-none">{student?.name}</p>
                              <p className="text-[10px] text-slate-500 mt-1">{student?.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full bg-brand-blue" />
                            <span className="text-sm font-medium text-slate-300">{cls?.name}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-col">
                            <span className="text-sm text-slate-200">{format(new Date(record.timestamp), 'MMM dd, yyyy')}</span>
                            <span className="text-xs text-slate-500">{format(new Date(record.timestamp), 'HH:mm:ss')}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-xs text-slate-400 font-medium bg-white/5 px-2 py-1 rounded">
                            {record.location ? 'Campus Verified' : 'Manual Entry'}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className={cn(
                            "px-2.5 py-1 rounded-lg text-[10px] font-bold tracking-wider uppercase",
                            record.status === 'PRESENT' ? "bg-emerald-500/10 text-emerald-400" :
                            record.status === 'LATE' ? "bg-amber-500/10 text-amber-400" :
                            "bg-red-500/10 text-red-400"
                          )}>
                            {record.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button className="p-2 text-slate-500 hover:text-brand-blue transition-colors">
                            <ChevronRight className="w-5 h-5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                ) : (
                  <tr>
                    <td colSpan={6} className="px-6 py-20 text-center">
                      <div className="flex flex-col items-center gap-3 opacity-20">
                        <CalendarIcon className="w-16 h-16" />
                        <p className="text-lg font-medium italic">No attendance records found</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          
          <div className="p-6 border-t border-white/5 bg-white/[0.01] flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Showing {displayRecords.length} records</span>
            <div className="flex gap-2">
              <button className="px-3 py-1 rounded-lg hover:bg-white/5 disabled:opacity-30" disabled>Previous</button>
              <button className="px-3 py-1 rounded-lg bg-white/5 text-white">1</button>
              <button className="px-3 py-1 rounded-lg hover:bg-white/5 disabled:opacity-30" disabled>Next</button>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Attendance;
