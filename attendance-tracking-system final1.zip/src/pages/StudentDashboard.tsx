import { useStore } from '../store/useStore';
import StatCard from '../components/common/StatCard';
import { BookOpen, CheckCircle, XCircle, TrendingUp, Calendar as CalendarIcon, MapPin, QrCode } from 'lucide-react';
import { cn } from '../utils/cn';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell
} from 'recharts';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';

const StudentDashboard = () => {
  const { currentUser, attendance, classes } = useStore();
  
  const studentAttendance = attendance.filter(a => a.studentId === currentUser?.id);
  const myClasses = classes.filter(c => c.students.includes(currentUser?.id || ''));

  const subjectData = myClasses.map(c => {
    const percentage = Math.round(Math.random() * 30 + 70); // Mock percentage for display
    return { name: c.name, percentage };
  });

  return (
    <div className="space-y-6 md:space-y-8 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-zinc-100">My Progress</h2>
          <p className="text-slate-500 dark:text-zinc-500 text-sm font-medium">Tracking {myClasses.length} active courses</p>
        </div>
        <Link to="/scan" className="bg-brand-blue hover:bg-brand-blue/90 text-white px-5 py-3 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-xl shadow-brand-blue/20 w-full sm:w-auto">
          <QrCode className="w-5 h-5" />
          Quick Scan
        </Link>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatCard title="Attendance" value="84%" icon={TrendingUp} color="bg-indigo-500" trend="2.4%" trendUp />
        <StatCard title="Present" value={studentAttendance.length} icon={CheckCircle} color="bg-emerald-500" />
        <StatCard title="Absent" value="4" icon={XCircle} color="bg-red-500" />
        <StatCard title="Courses" value={myClasses.length} icon={BookOpen} color="bg-purple-500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-dark p-6 md:p-8 rounded-[2.5rem] border border-white/5">
          <h3 className="text-lg font-bold text-white mb-8">Course Participation</h3>
          <div className="h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#27272a" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 10 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 10 }} />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                  contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '16px', color: '#fff' }}
                />
                <Bar dataKey="percentage" radius={[10, 10, 0, 0]} barSize={32}>
                  {subjectData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.percentage < 75 ? '#f43f5e' : '#3f51b5'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-dark p-6 md:p-8 rounded-[2.5rem] border border-white/5 flex flex-col">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-white">Registry Log</h3>
            <button className="text-[10px] font-black text-brand-blue uppercase tracking-widest hover:underline">Full History</button>
          </div>
          
          <div className="space-y-6 flex-1 max-h-[300px] overflow-y-auto pr-2 scrollbar-none">
            {studentAttendance.length > 0 ? (
              studentAttendance.map((rec) => {
                const cls = classes.find(c => c.id === rec.classId);
                return (
                  <div key={rec.id} className="flex gap-4 items-start group">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center shrink-0 border border-emerald-500/20 group-hover:scale-110 transition-transform">
                      <CalendarIcon className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold text-white truncate">{cls?.name}</h4>
                      <p className="text-[10px] text-zinc-500 mb-1 font-medium">{format(new Date(rec.timestamp), 'MMM dd • HH:mm')}</p>
                      <div className="flex items-center gap-1 text-[10px] font-bold text-zinc-600 uppercase tracking-tighter">
                        <MapPin className="w-3 h-3" />
                        <span>University Hall A</span>
                      </div>
                    </div>
                    <span className="text-[8px] font-black text-emerald-400 bg-emerald-400/5 px-2 py-0.5 rounded border border-emerald-400/20 uppercase tracking-widest">
                      In
                    </span>
                  </div>
                );
              })
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-zinc-600 py-10">
                <CalendarIcon className="w-12 h-12 mb-4 opacity-10" />
                <p className="text-xs font-bold uppercase tracking-widest">No recent scans</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Calendar Heatmap View */}
      <div className="glass-dark p-6 md:p-10 rounded-[2.5rem] border border-white/5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-10 gap-4">
          <h3 className="text-lg font-bold text-white flex items-center gap-3">
            <CalendarIcon className="text-brand-blue w-5 h-5" />
            Attendance Heatmap
          </h3>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full" />
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Present</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 bg-red-500 rounded-full" />
              <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Absent</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-7 gap-2 sm:gap-4">
          {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(day => (
            <div key={day} className="text-center text-[10px] font-black text-zinc-600 uppercase tracking-widest mb-2">{day}</div>
          ))}
          {Array.from({ length: 31 }).map((_, i) => {
            const isPresent = [2, 5, 8, 12, 15, 19, 22, 26].includes(i);
            const isAbsent = [10, 24].includes(i);
            return (
              <div 
                key={i} 
                className={cn(
                  "aspect-square rounded-xl flex items-center justify-center text-[10px] font-bold transition-all hover:scale-110 cursor-pointer border",
                  isPresent ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                  isAbsent ? "bg-red-500/10 text-red-400 border-red-500/20" :
                  "bg-white/[0.02] text-zinc-700 border-white/5"
                )}
              >
                {i + 1}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
