import { useStore } from '../store/useStore';
import StatCard from '../components/common/StatCard';
import { Users, BookOpen, UserCheck, AlertTriangle, TrendingUp, Calendar } from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, Cell
} from 'recharts';

const data = [
  { name: 'Mon', attendance: 85 },
  { name: 'Tue', attendance: 88 },
  { name: 'Wed', attendance: 92 },
  { name: 'Thu', attendance: 82 },
  { name: 'Fri', attendance: 78 },
];

const classData = [
  { name: 'CS101', value: 92 },
  { name: 'CS202', value: 85 },
  { name: 'MA105', value: 72 },
  { name: 'PH102', value: 65 },
];

const AdminDashboard = () => {
  const { users, classes } = useStore();
  
  const studentCount = users.filter(u => u.role === 'STUDENT').length;
  const teacherCount = users.filter(u => u.role === 'TEACHER').length;

  return (
    <div className="space-y-6 md:space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-zinc-100">System Overview</h2>
          <p className="text-slate-500 dark:text-zinc-500 text-sm">Manage institutional performance</p>
        </div>
        <button className="bg-brand-blue hover:bg-brand-blue/90 text-white px-5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-brand-blue/20">
          <Calendar className="w-4 h-4" />
          Generate Report
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatCard title="Students" value={studentCount} icon={Users} color="bg-indigo-500" trend="12%" trendUp />
        <StatCard title="Teachers" value={teacherCount} icon={UserCheck} color="bg-emerald-500" trend="2%" trendUp />
        <StatCard title="Classes" value={classes.length} icon={BookOpen} color="bg-purple-500" />
        <StatCard title="Alerts" value="12" icon={AlertTriangle} color="bg-amber-500" trend="5%" trendUp={false} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-dark p-6 md:p-8 rounded-[2rem] border border-white/5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <TrendingUp className="text-brand-blue w-5 h-5" />
              Attendance Trends
            </h3>
            <select className="bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-[10px] font-bold text-slate-400 focus:outline-none uppercase tracking-widest">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorAttendance" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3f51b5" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#3f51b5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="currentColor" className="text-slate-800/20" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 10 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 10 }} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a', borderRadius: '16px', color: '#fff' }}
                  itemStyle={{ color: '#7986cb' }}
                />
                <Area type="monotone" dataKey="attendance" stroke="#3f51b5" fillOpacity={1} fill="url(#colorAttendance)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-dark p-6 md:p-8 rounded-[2rem] border border-white/5">
          <h3 className="text-lg font-bold text-white mb-8">Class Performance</h3>
          <div className="h-[250px] md:h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={classData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#27272a" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fill: '#71717a', fontSize: 10 }} width={50} />
                <Tooltip 
                  cursor={{ fill: 'rgba(255,255,255,0.02)' }}
                  contentStyle={{ backgroundColor: '#18181b', border: 'none', borderRadius: '16px', color: '#fff' }}
                />
                <Bar dataKey="value" radius={[0, 8, 8, 0]} barSize={20}>
                  {classData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.value < 75 ? '#f43f5e' : '#3f51b5'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
