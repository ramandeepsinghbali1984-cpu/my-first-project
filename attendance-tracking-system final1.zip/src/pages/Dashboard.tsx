import { useStore } from '../store/useStore';
import AdminDashboard from './AdminDashboard';
import TeacherDashboard from './TeacherDashboard';
import StudentDashboard from './StudentDashboard';
import Layout from '../components/layout/Layout';

const Dashboard = () => {
  const { currentUser } = useStore();

  if (!currentUser) return null;

  const renderDashboard = () => {
    switch (currentUser.role) {
      case 'ADMIN':
        return <AdminDashboard />;
      case 'TEACHER':
        return <TeacherDashboard />;
      case 'STUDENT':
        return <StudentDashboard />;
      default:
        return <div>Access Denied</div>;
    }
  };

  return (
    <Layout>
      {renderDashboard()}
    </Layout>
  );
};

export default Dashboard;
