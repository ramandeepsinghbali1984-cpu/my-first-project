import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserRole = 'ADMIN' | 'TEACHER' | 'STUDENT';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ALERT';
  timestamp: string;
  isRead: boolean;
}

export interface Class {
  id: string;
  name: string;
  code: string;
  teacherId: string;
  students: string[]; // user IDs
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  sessionId: string;
  timestamp: string;
  status: 'PRESENT' | 'ABSENT' | 'LATE';
  location?: { lat: number; lng: number };
}

export interface Session {
  id: string;
  classId: string;
  teacherId: string;
  startTime: string;
  endTime: string;
  qrCode: string;
  isActive: boolean;
}

interface AppState {
  currentUser: User | null;
  users: User[];
  classes: Class[];
  sessions: Session[];
  attendance: AttendanceRecord[];
  notifications: Notification[];
  
  // Actions
  login: (email: string, password: string, role: UserRole) => { success: boolean; message?: string };
  logout: () => void;
  addAttendance: (record: AttendanceRecord) => void;
  createSession: (session: Session) => void;
  endSession: (sessionId: string) => void;
  addClass: (newClass: Class) => void;
  updateUser: (userId: string, updates: Partial<User>) => void;
  addUser: (user: User) => void;
  deleteUser: (userId: string) => void;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [
        { id: 'karan', name: 'Karan Admin', email: 'karan@school.edu', role: 'ADMIN' },
        { id: 'harsh', name: 'Harsh Teacher', email: 'harsh@school.edu', role: 'TEACHER' },
        { id: 'raman', name: 'Ramandeep Student', email: 'ramandeep@school.edu', role: 'STUDENT' },
      ],
      classes: [
        { id: 'c1', name: 'Computer Science 101', code: 'CS101', teacherId: 'harsh', students: ['raman'] },
        { id: 'c2', name: 'Data Structures', code: 'CS202', teacherId: 'harsh', students: ['raman'] },
        { id: 'c4', name: 'Software Engineering', code: 'SE101', teacherId: 'harsh', students: ['raman'] },
      ],
      sessions: [
        { id: 's1', classId: 'c1', teacherId: 'harsh', startTime: new Date(Date.now() - 3600000).toISOString(), endTime: new Date().toISOString(), qrCode: 'old-1', isActive: false },
        { id: 's2', classId: 'c2', teacherId: 'harsh', startTime: new Date(Date.now() - 7200000).toISOString(), endTime: new Date().toISOString(), qrCode: 'old-2', isActive: false },
      ],
      attendance: [
        { id: 'a1', studentId: 'raman', classId: 'c1', sessionId: 's1', timestamp: new Date(Date.now() - 3500000).toISOString(), status: 'PRESENT' },
        { id: 'a2', studentId: 'raman', classId: 'c2', sessionId: 's2', timestamp: new Date(Date.now() - 7100000).toISOString(), status: 'PRESENT' },
      ],
      notifications: [
        { id: 'n1', title: 'System Security Patch', message: 'MFA protocols have been updated for all administrative accounts.', type: 'ALERT', timestamp: new Date().toISOString(), isRead: false },
        { id: 'n2', title: 'Performance Milestone', message: 'Average institutional attendance reached 92% this month.', type: 'INFO', timestamp: new Date(Date.now() - 86400000).toISOString(), isRead: false },
        { id: 'n3', title: 'Low Attendance Alert', message: '3 students in your CS101 class have dropped below the 75% threshold.', type: 'WARNING', timestamp: new Date(Date.now() - 43200000).toISOString(), isRead: false },
        { id: 'n4', title: 'Session Successful', message: 'Your Data Structures session QR was scanned by 24 students.', type: 'INFO', timestamp: new Date(Date.now() - 3600000).toISOString(), isRead: true },
        { id: 'n5', title: 'Assignment Reminder', message: 'New research paper uploaded to the Computer Science portal.', type: 'INFO', timestamp: new Date(Date.now() - 172800000).toISOString(), isRead: true },
        { id: 'n6', title: 'Attendance Flagged', message: 'Ramandeep Kaur was marked absent for 3 consecutive days.', type: 'WARNING', timestamp: new Date(Date.now() - 259200000).toISOString(), isRead: false },
      ],

      login: (email, password, role) => {
        const state = get();
        const user = state.users.find((u) => u.email === email && u.role === role);
        
        if (!user) {
          return { success: false, message: 'Invalid credentials or role.' };
        }
        
        if (password !== '87654321') {
          return { success: false, message: 'Wrong password. Access denied.' };
        }

        set({ currentUser: user });
        return { success: true };
      },
      logout: () => set({ currentUser: null }),
      addAttendance: (record) => set((state) => ({
        attendance: [...state.attendance, record]
      })),
      createSession: (session) => set((state) => ({
        sessions: [...state.sessions, session]
      })),
      endSession: (sessionId) => set((state) => ({
        sessions: state.sessions.map(s => s.id === sessionId ? { ...s, isActive: false } : s)
      })),
      addClass: (newClass) => set((state) => ({
        classes: [...state.classes, newClass]
      })),
      updateUser: (userId, updates) => set((state) => {
        const updatedUsers = state.users.map(u => u.id === userId ? { ...u, ...updates } : u);
        const updatedCurrentUser = state.currentUser?.id === userId ? { ...state.currentUser, ...updates } : state.currentUser;
        return { users: updatedUsers, currentUser: updatedCurrentUser };
      }),
      addUser: (user) => set((state) => ({
        users: [...state.users, user]
      })),
      deleteUser: (userId) => set((state) => ({
        users: state.users.filter(u => u.id !== userId)
      })),
      markNotificationRead: (id) => set((state) => ({
        notifications: state.notifications.map(n => n.id === id ? { ...n, isRead: true } : n)
      })),
      clearNotifications: () => set((state) => ({
        notifications: []
      })),
    }),
    { name: 'attendance-storage' }
  )
);
