import { LucideIcon } from 'lucide-react';
import { cn } from '../../utils/cn';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendUp?: boolean;
  color: string;
}

const StatCard = ({ title, value, icon: Icon, trend, trendUp, color }: StatCardProps) => {
  return (
    <div className="bg-white dark:bg-zinc-900/40 p-5 md:p-6 rounded-[1.5rem] border border-slate-200 dark:border-white/5 relative overflow-hidden group transition-all duration-300">
      <div className="flex items-start justify-between">
        <div className="z-10">
          <p className="text-slate-500 dark:text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-1.5">{title}</p>
          <h3 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">{value}</h3>
          
          {trend && (
            <div className="flex items-center gap-1.5 mt-2">
              <span className={cn(
                "text-[10px] font-black px-1.5 py-0.5 rounded-lg flex items-center gap-0.5 border",
                trendUp ? "bg-emerald-500/10 text-emerald-500 border-emerald-500/20" : "bg-red-500/10 text-red-500 border-red-500/20"
              )}>
                {trendUp ? '↑' : '↓'} {trend}
              </span>
            </div>
          )}
        </div>
        
        <div className={cn(
          "w-10 h-10 md:w-12 md:h-12 rounded-2xl flex items-center justify-center transition-all duration-500 group-hover:rotate-6 group-hover:scale-110 z-10 border border-transparent",
          color.includes('indigo') || color.includes('blue') ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' :
          color.includes('emerald') ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
          color.includes('amber') ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
          'bg-purple-500/10 text-purple-400 border-purple-500/20'
        )}>
          <Icon className="w-5 h-5 md:w-6 md:h-6" />
        </div>
      </div>
      
      {/* Subtle background decoration */}
      <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-slate-900/5 dark:bg-white/5 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-500" />
    </div>
  );
};

export default StatCard;
