import { Bell, Search, User, QrCode, X, Check, AlertTriangle, Info } from 'lucide-react';
import { useStore } from '@/store/useStore';
import { Link } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

const Navbar = () => {
  const { currentUser, notifications, markNotificationRead, clearNotifications } = useStore();
  const [showNotifs, setShowNotifs] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifs(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!currentUser) return null;

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <nav className="h-20 sticky top-0 z-[60] px-6 md:px-12 flex items-center justify-between border-b border-white/[0.03] bg-zinc-950/50 backdrop-blur-3xl">
      <div className="flex items-center gap-4 flex-1">
        <div className="md:hidden flex items-center gap-3">
           <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/10">
             <QrCode className="text-white w-5 h-5" />
           </div>
           <span className="text-xl font-black tracking-tighter text-white">Attendify</span>
        </div>
        
        <div className="relative group w-full max-w-sm hidden md:block">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600 group-focus-within:text-blue-500 transition-colors" />
          <input
            type="text"
            placeholder="Search resources..."
            className="w-full bg-white/[0.02] border border-white/[0.05] rounded-xl py-2.5 pl-11 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500/30 transition-all placeholder:text-zinc-700"
          />
        </div>
      </div>

      <div className="flex items-center gap-4 md:gap-6">
        <div className="relative" ref={notifRef}>
          <button 
            onClick={() => setShowNotifs(!showNotifs)}
            className="relative p-2.5 text-zinc-500 hover:text-white transition-all bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.05] rounded-xl"
          >
            <Bell className="w-5 h-5" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-[9px] font-black flex items-center justify-center rounded-full border-2 border-zinc-950">
                {unreadCount}
              </span>
            )}
          </button>

          <AnimatePresence>
            {showNotifs && (
              <motion.div 
                initial={{ opacity: 0, y: 15, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 15, scale: 0.98 }}
                className="absolute right-0 mt-4 w-80 md:w-[400px] bg-zinc-900 border border-white/[0.08] shadow-[0_20px_50px_rgba(0,0,0,0.5)] rounded-[2rem] overflow-hidden z-[100]"
              >
                <div className="p-6 border-b border-white/[0.05] flex items-center justify-between bg-white/[0.01]">
                  <h3 className="text-sm font-black text-white uppercase tracking-widest">Alerts Center</h3>
                  <button 
                    onClick={clearNotifications}
                    className="text-[10px] font-black text-zinc-500 hover:text-white transition-colors uppercase tracking-widest"
                  >
                    Clear All
                  </button>
                </div>
                <div className="max-h-[450px] overflow-y-auto">
                  {notifications.length > 0 ? (
                    notifications.map((n) => (
                      <div 
                        key={n.id} 
                        onClick={() => markNotificationRead(n.id)}
                        className={`p-5 border-b border-white/[0.03] last:border-none cursor-pointer transition-colors hover:bg-white/[0.03] ${!n.isRead ? 'bg-white/[0.01]' : ''}`}
                      >
                        <div className="flex gap-4">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
                            n.type === 'ALERT' ? 'bg-red-500/10 text-red-500 border-red-500/20' :
                            n.type === 'WARNING' ? 'bg-amber-500/10 text-amber-500 border-amber-500/20' :
                            'bg-blue-500/10 text-blue-500 border-blue-500/20'
                          }`}>
                            {n.type === 'ALERT' ? <AlertTriangle className="w-5 h-5" /> :
                             n.type === 'WARNING' ? <Info className="w-5 h-5" /> :
                             <Check className="w-5 h-5" />}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-white mb-1">{n.title}</p>
                            <p className="text-[11px] text-zinc-500 leading-relaxed mb-2 line-clamp-2">{n.message}</p>
                            <p className="text-[9px] font-black text-zinc-700 uppercase tracking-widest">
                              {format(new Date(n.timestamp), 'MMM dd • HH:mm')}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-12 text-center">
                      <p className="text-xs text-zinc-600 font-bold uppercase tracking-widest">All caught up</p>
                    </div>
                  )}
                </div>
                {notifications.length > 0 && (
                  <button className="w-full py-5 text-[10px] font-black text-blue-500 hover:text-blue-400 bg-white/[0.01] border-t border-white/[0.05] transition-colors uppercase tracking-[0.2em]">
                    System Logs
                  </button>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="h-8 w-px bg-white/[0.05] hidden sm:block" />

        <Link to="/settings" className="flex items-center gap-4 group cursor-pointer">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-bold text-white group-hover:text-blue-500 transition-colors">{currentUser.name}</p>
            <p className="text-[9px] text-zinc-600 font-black uppercase tracking-widest">{currentUser.role}</p>
          </div>
          <div className="w-11 h-11 rounded-xl bg-zinc-900 flex items-center justify-center border border-white/[0.08] group-hover:border-blue-500/50 group-hover:shadow-[0_0_20px_rgba(59,130,246,0.2)] transition-all overflow-hidden">
             {currentUser.avatar ? (
               <img src={currentUser.avatar} alt="" className="w-full h-full object-cover" />
             ) : (
               <User className="w-5 h-5 text-zinc-600 group-hover:text-blue-500 transition-colors" />
             )}
          </div>
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
