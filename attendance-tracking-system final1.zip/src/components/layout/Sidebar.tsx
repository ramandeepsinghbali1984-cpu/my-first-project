import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  BookOpen, 
  QrCode, 
  Calendar, 
  Settings, 
  LogOut, 
  BarChart3
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { motion } from 'framer-motion';

const Sidebar = () => {
  const { currentUser, logout } = useStore();
  const navigate = useNavigate();

  if (!currentUser) return null;

  const links = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
    { name: 'Attendance', path: '/attendance', icon: Calendar, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
    { name: 'Reports', path: '/reports', icon: BarChart3, roles: ['ADMIN', 'TEACHER'] },
    { name: 'People', path: '/people', icon: Users, roles: ['ADMIN'] },
    { name: 'Classes', path: '/classes', icon: BookOpen, roles: ['ADMIN', 'TEACHER'] },
    { name: 'Scan QR', path: '/scan', icon: QrCode, roles: ['STUDENT'] },
    { name: 'Account Settings', path: '/settings', icon: Settings, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
  ];

  const filteredLinks = links.filter(link => link.roles.includes(currentUser.role));

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <aside className="w-72 bg-zinc-950 h-screen sticky top-0 border-r border-white/[0.03] hidden md:flex flex-col z-50">
      <div className="p-10">
        <div className="flex items-center gap-4 mb-16 px-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center shadow-2xl shadow-blue-500/20 transform -rotate-3">
            <QrCode className="text-white w-5 h-5" />
          </div>
          <span className="text-2xl font-black tracking-tighter text-white">Attendify</span>
        </div>

        <nav className="space-y-1.5">
          {filteredLinks.map((link) => (
            <NavLink
              key={link.path}
              to={link.path}
            >
              {({ isActive }) => (
                <div className={cn(
                  "flex items-center gap-4 px-5 py-4 rounded-2xl transition-all duration-300 group relative overflow-hidden",
                  isActive 
                    ? "bg-white/[0.05] text-white" 
                    : "text-zinc-500 hover:bg-white/[0.02] hover:text-zinc-300"
                )}>
                  {isActive && (
                    <motion.div 
                      layoutId="sidebar-active"
                      className="absolute left-0 top-3 bottom-3 w-1 bg-blue-500 rounded-full"
                    />
                  )}
                  <link.icon className={cn("w-5 h-5 transition-all duration-300", isActive ? "text-blue-500" : "text-zinc-600 group-hover:text-zinc-400")} />
                  <span className="font-bold text-[10px] uppercase tracking-[0.15em]">{link.name}</span>
                </div>
              )}
            </NavLink>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-10 border-t border-white/[0.03] bg-zinc-950/50">
        <button
          onClick={handleLogout}
          className="flex items-center gap-4 px-5 py-5 w-full rounded-2xl text-zinc-500 hover:text-red-500 hover:bg-red-500/5 transition-all duration-300 group"
        >
          <LogOut className="w-5 h-5 transition-transform group-hover:translate-x-1" />
          <span className="font-bold text-[10px] uppercase tracking-[0.15em]">Log Out</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
