import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Calendar, 
  Settings, 
  QrCode,
  BookOpen,
  BarChart3
} from 'lucide-react';
import { useStore } from '@/store/useStore';
import { cn } from '@/utils/cn';
import { motion } from 'framer-motion';

const MobileNav = () => {
  const { currentUser } = useStore();

  if (!currentUser) return null;

  const links = [
    { name: 'Home', path: '/', icon: LayoutDashboard, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
    { name: 'History', path: '/attendance', icon: Calendar, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
    { name: 'Scan', path: '/scan', icon: QrCode, roles: ['STUDENT'] },
    { name: 'Classes', path: '/classes', icon: BookOpen, roles: ['ADMIN', 'TEACHER'] },
    { name: 'Reports', path: '/reports', icon: BarChart3, roles: ['ADMIN', 'TEACHER'] },
    { name: 'Settings', path: '/settings', icon: Settings, roles: ['ADMIN', 'TEACHER', 'STUDENT'] },
  ];

  const filteredLinks = links.filter(link => link.roles.includes(currentUser.role));

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl border-t border-slate-200 dark:border-white/5 px-6 py-3 z-[100] flex justify-between items-center safe-area-bottom">
      {filteredLinks.map((link) => (
        <NavLink
          key={link.path}
          to={link.path}
          className="group flex flex-col items-center gap-1 transition-all duration-200"
        >
          {({ isActive }) => (
            <>
              <link.icon className={cn("w-5 h-5", "transition-transform duration-200", isActive ? "text-blue-600 scale-110" : "text-slate-400")} />
              <span className={cn("text-[8px] font-bold uppercase tracking-widest", isActive ? "text-blue-600" : "text-slate-400")}>{link.name}</span>
              {isActive && (
                <motion.div layoutId="nav-dot" className="w-1 h-1 bg-blue-600 rounded-full" />
              )}
            </>
          )}
        </NavLink>
      ))}
    </nav>
  );
};

export default MobileNav;
